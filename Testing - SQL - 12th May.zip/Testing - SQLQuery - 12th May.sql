--create		: create new object (databse, table, view etc.)
create database testing

-- use databse : change database
use testing 

--create new table in selected db
create table product 
(
pid int,
pname varchar(100),
pprice int,
sprice int
)

select * from product 

---alter		: mofify the existing object
--add new column in existing table
alter table product 
add mfd date 

--alter table and modify data type or size
alter table product 
alter column pname varchar(20)

--alter table and drop column
alter table product  
drop column mfd 

--drop 		: remove the existing object, column 
--drop table table 

drop table prodct

---truncate 	: remove all data but structure will remain same 	
--truncate doesn't support where 
truncate table product 

select * from product 

--insert	: save new data 
insert into product
values(1,'dove',30,35)

--insert multiple rows
insert into product
values(2,'iphone',60000,67000),
(3,'hp laptop',31000,35000),
(4,'sony tv',30000,35000)


--view data 
-- * : show all columns
select * from product

--show selected columns 
select pid,pname from product

--udpate	: modify existing data(row)
update product
set sprice = 40
where pid =1


-- delete 	: remove data 	with condition or without condition 	
delete from product where pid  =1 --delete with condition 

delete product  --remove all data 

select * from product 


--Conditional:
		-->
		select * from product where pid> 1

		--		>=
		select * from product where pid>=2
		
		--<
		select * from product where pid< 2
		--<=
		select * from product where pid<= 2
		--=
		select * from product where pid= 2
		--!=		or <>
		select * from product where pid != 2
		select * from product where pid <> 2

--Keywords:
		--in : show from given list 
		select * from product where pid in (1,3,4)

		--not in
		select * from product where pid not in (1,3,4)

		--between : in given range (inclusive)
		select * from product where pid between 1 and 3

		--not between  : exclusive
		select * from product where pid not between 1 and 3

		--is null 
		select * from product where  sprice is null

		--is not null
		select * from product where  sprice is not null
--wild card : pattern matching
--%  : match any char and any no of times
--_  : match any char with given no of times(fix length)
		--like 
		select * from product where pname like 'd%' --start with d
		select * from product where pname like '%e' --end with e
		select * from product where pname like '%e%' --contains e 

		select * from product where pname like 'd___' --any four char after d


		select * from product where pname like 'd%a_x%' 

		--not like 
		select * from product where pname not like '%e%'
--order by	: to arrange data in asc or desc order	
select * from product order by sprice asc --default is asc
select * from product order by sprice desc
select * from product order by pname asc
select * from product order by 2 desc --by 2nd column

--group by	: to summarize the data based on given condition 
select pname , count(*) from product 
group by pname 

--Function	: is set of command or statement which can reuse 
--		Example:
--		-sum(), max(), min(), left(), upper(), lower() etc.

select pname , count(*),sum(sprice) from product 
group by pname 

select pname , count(*),sum(sprice),max(pprice), min(pprice) from product 
group by pname 

--Having		: to apply the filter after group by
		--Example: show duplicate rows 
select pname , count(*),sum(sprice) from product 
group by pname 
having count(*) >1


--Top, Distinct keyword :
--top : to return top given no of rows
select top 2 * from product 
select top 4 * from product 

--distinct : show unique rows
select * from product 
select distinct * from product 
select distinct pname from product 

--select into     : create new table from existing table 
select distinct * into product_dst from product 

select * from product_dst 


--Subquery	: is nested query or query inside query 
--show 2nd highest sprice 
select top 1 * 
from 	(select top 2 * from product order by sprice desc) temp 
order by sprice asc 


/*
query squence:
select
1 from  
2 where
3. group by
4. having
5. order by
*/

--union		: to merge two or more than two tables vertically
--		-table structure should be same 
--There are flowing types of union :
--i. union : return distinct or unique rows
select * from product
union 
select * from product_dst

--ii. union all : show all rows 
select * from product
union all
select * from product_dst

--Join		: to merge two to more than two tables horizentally
		--at least one column shold be same all tables

create table sales
(
oid int,
pid  int,
customer varchar(100),
qty int,
odate datetime
)

insert into sales 
values(1,2,'nitin',10,getdate())


insert into sales 
values(2,2,'nitin',10,getdate()),
(3,3,'Divya',1,getdate()),
(4,1,'Chahat',4,getdate()),
(5,20,'Monika',7,getdate()),
(6,2,'Rahul',20,getdate())

select * from product
select * from sales 
--output: oid custname pname qty sprice total_price odate 
/*
There are follownig types of join 
i. inner join		: return common or matching rows
ii. outer join / full outer join  : return all rows
 a. left join   : return all rows from left table and matching from right table
 b. right join  : return all rows from right  and matching from left table

other types of join:
	-cross		: is also known as cartisan product 
				: this is not recommaned to use 
	-self join 
*/

--inner join 
select s.oid,s.customer, p.pname, s.qty, p.sprice, s.qty*p.sprice as total, s.odate
from product p inner join sales  s
	on p.pid = s.pid 


--more the two tables
select s.oid,s.customer, p.pname, s.qty, p.sprice, s.qty*p.sprice as total, s.odate,sum(t2.id)
from product p inner join sales  s
	on p.pid = s.pid 
  inner join table2 as t2
	on p.tid = t2.tid 
where 
group by s.oid,s.customer, p.pname, s.qty, p.sprice,s.odate





--left 
select s.oid,s.customer, p.pname, s.qty, p.sprice, s.qty*p.sprice as total, s.odate
from product p left join sales  s
	on p.pid = s.pid 

--right
select s.oid,s.customer, p.pname, s.qty, p.sprice, s.qty*p.sprice as total, s.odate
from product p right join sales  s
	on p.pid = s.pid 

--full outer join 
select s.oid,s.customer, p.pname, s.qty, p.sprice, s.qty*p.sprice as total, s.odate
from product p full outer join sales  s
	on p.pid = s.pid 


---cross join  10 * 6 = 60
select * 
from product , sales 

--cross join can be use as a inner join 
select sales.oid,sales.customer,product.pname,product.sprice
from product , sales 
where product.pid = sales.pid

--self join : apply the join with same table
select * from employee

--output:
-- eid name mgrname 

select e.eid, e.name , m.name as mgrname
from employee as e left join employee as m
	on e.mgr_id = m.eid 
