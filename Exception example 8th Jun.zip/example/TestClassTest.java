package example;



public class TestClassTest {


  public static void main(String[] arg) {
    
  

    int a,b,c,d; //declare variable 
	a =5;
	b =7;
	c =a*a; //expression 
	d= b*b*b; //expression
	
	System.out.println("square of two numbers "+c);
	System.out.println("square of two numbers "+d);
	
	
}

}