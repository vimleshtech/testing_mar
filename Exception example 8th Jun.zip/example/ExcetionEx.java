package example;

import java.util.Scanner;

public class ExcetionEx {

	public static void add(int a, int b) {
		
	}
	public static void main(String[] args) {

		int x,y;
		x=33;
		y=33;
		
		add(x,y);
		
		int n,d,o;		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("enter data ");
		n = sc.nextInt();
		
		System.out.println("enter data ");
		d = sc.nextInt();
		
		
		try {
			
			if(d<0)
			{
				Exception abc = new Exception("Divisor cannot be less than  0");
				throw abc;
				
			}
			o =n/d;
			System.out.println("div = "+o);
		}
		catch (ArithmeticException e) {
			System.out.println("maths error");
		}
		catch(ArrayIndexOutOfBoundsException e)
		{
			System.out.println("array out of index");
		}
		catch (Exception e) 
		{
			System.out.println(e.toString());
		}
		finally {
			System.out.println("end of the code");
		}
		
		
		//add
		o = n+d;
		System.out.println("add = "+o);
		
		
		
		

	}

}
